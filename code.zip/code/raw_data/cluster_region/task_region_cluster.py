#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/24
import matplotlib.pyplot as plt
import numpy as np
from raw_data.cluster_region.hull import convex

dates = {"2016-8-{0}".format(i) for i in range(1, 32)}
weekends = {"2016-8-{0}".format(i) for i in [6, 7, 13, 14, 20, 21, 27, 28]}
locations = []
remove_locations = {
    (121.221, 31.274),
    (121.211, 31.417),
    (131.356, 31.442),
    (121.23, 31.085),
    (121.234, 31.058),
    (121.232, 31.054),
    (121.241, 31.057),
    (121.246, 31.046),
    (121.246, 31.031),
    (121.657, 31.035),
    (121.745, 31.045),
    (121.744, 31.045),
}
with open("./locations.csv", "w") as f:
    f.write("x,y\n")
    for date in dates - weekends:
        raw_data = open("./mobike_shanghai_{0}.csv".format(date))
        k = 0
        for each_data in raw_data:
            if k == 0:
                k += 1
                continue
            bikeid, start_time, during_time, location_x, location_y = each_data.split(",")
            if float(location_y) < 30.95 or float(location_y) > 31.440:
                continue
            if float(location_x) < 121.2 or float(location_x) > 121.71:
                continue
            if (float(location_x), float(location_y)) not in remove_locations:
                locations.append([float(location_x), float(location_y), during_time])
                f.write("{0},{1}".format(location_x, location_y))
        raw_data.close()
locations = np.array(locations, dtype=np.float32)

# 凸包算法圈地
delta = 10
bound_max_x, bound_max_y, bound_min_x, bound_min_y = 0, 0, 300000, 300000
for location in locations:
    x, y, t = location
    bound_max_x = max(bound_max_x, x)
    bound_min_x = min(bound_min_x, x)
    bound_max_y = max(bound_max_y, y)
    bound_min_y = min(bound_min_y, y)
convex_hull = np.array(convex(locations[:, 0:2].tolist()))
plt.plot(convex_hull[:, 0], convex_hull[:, 1], "k-")
plt.plot(np.array([bound_min_x, bound_max_x, bound_max_x, bound_min_x, bound_min_x]),
         np.array([bound_min_y, bound_min_y, bound_max_y, bound_max_y, bound_min_y]), "k-")
POT_center = []
for x in range(int(bound_min_x * 1000) + delta, int(bound_max_x * 1000) - delta, 2 * delta):
    for y in range(int(bound_min_y * 1000) + delta, int(bound_max_y * 1000) - delta, 2 * delta):
        POT_center.append([x / 1000, y / 1000])
POT_center = np.array(POT_center)
print(POT_center)
max_bike_number = 0

with open("./POI_center.csv", "w") as f:
    f.write("region_id,x,y,bike_num,during_time\n")
    delta_float = delta / 1000
    k = 0
    for center in POT_center:
        print(center)
        bike_number = 0
        total_times = 0
        for location in locations:
            if center[0] - delta_float <= location[0] <= center[0] + delta_float and \
               center[1] - delta_float <= location[1] <= center[1] + delta_float:
                bike_number += 1
                total_times += location[2]
        if bike_number >= 22:
            time_avg = total_times / bike_number if bike_number >= 1 else 0
            k += 1
            f.write("{0},{1},{2},{3},{4}\n".format(k, center[0], center[1], int(np.ceil(bike_number / 22)), int(np.round(time_avg))))
            max_bike_number = max(max_bike_number, int(np.ceil(bike_number / 22)))
            min_x = center[0] - delta_float
            max_x = center[0] + delta_float
            min_y = center[1] - delta_float
            max_y = center[1] + delta_float
print(max_bike_number)

with open("./POI_center.csv", "r") as f:
    delta_float = delta / 1000
    k = 0
    for each_data in f:
        if k == 0:
            k += 1
            continue
        xx, x, y, bike_number, time_avg = each_data.split(",")
        center = float(x), float(y)
        bike_number = np.clip(np.ceil(int(bike_number) / max_bike_number * 10), 0, 10)
        time_avg = float(time_avg[:-1])
        min_x = center[0] - delta_float
        max_x = center[0] + delta_float
        min_y = center[1] - delta_float
        max_y = center[1] + delta_float
        plt.fill(np.array([min_x, max_x, max_x, min_x, min_x]), np.array([min_y, min_y, max_y, max_y, min_y]), "r", alpha=bike_number / 10)
        plt.plot(np.array([min_x, max_x, max_x, min_x, min_x]), np.array([min_y, min_y, max_y, max_y, min_y]), "k-")

with open("./locations.csv", "w") as f:
    f.write("x,y\n")
    for location in locations:
        x, y, _ = location
        f.write("{0},{1}\n".format(x / 1000, y / 1000))
plt.show()
