#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/22


def get_during_time(t1: str, t2: str) -> str:
    h1, m1 = t1.split(":")
    h2, m2 = t2.split(":")
    m1 = int(h1) * 60 + int(m1)
    m2 = int(h2) * 60 + int(m2)
    if m1 > m2:  # 如果跨越了一天
        return str(m2 + 1440 - m1)
    else:
        return str(m2 - m1)


# 将原始数据分割成为多个日期的数据
raw_data = open("../mobike_data/mobike_shanghai_sample_updated.csv", "r")
raw_data_split_date = {}
weekends = {"2016-8-{0}".format(i) for i in [6, 7, 13, 14, 20, 21, 27, 28]}
k = 0
for each_data in raw_data:
    if k == 0:
        k += 1
        continue
    detail_info, track_info = each_data.split(",\"")
    order_id, bikeid, userid, start_time, start_location_x, start_location_y, end_time, end_location_x, end_location_y = detail_info.split(",")
    date = start_time.split(" ")[0].replace("/", "-")
    if date in weekends:
        continue
    if date not in raw_data_split_date:
        raw_data_split_date[date] = open("./mobike_shanghai_{0}.csv".format(date), "w")
        raw_data_split_date[date].write("bikeid,start_time,during_time, location_x, location_y\n")
    each_line = ",".join([bikeid, start_time.split(" ")[1], get_during_time(start_time.split(" ")[1], end_time.split(" ")[1]), start_location_x, start_location_y])
    raw_data_split_date[date].write(each_line + "\n")
raw_data.close()
for date in raw_data_split_date.keys():
    raw_data_split_date[date].close()
