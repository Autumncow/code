#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/6/4

# 将原始数据分割成为多个日期的数据
raw_data = open("../mobike_data/mobike_shanghai_sample_updated.csv", "r")
raw_data_split_date = {}
k = 0
for each_data in raw_data:
    if k == 0:
        k += 1
        continue
    detail_info, track_info = each_data.split(",\"")
    order_id, bikeid, userid, start_time, start_location_x, start_location_y, end_time, end_location_x, end_location_y = detail_info.split(",")
    date = start_time.split(" ")[0].replace("/", "-")
    if date not in raw_data_split_date:
        raw_data_split_date[date] = open("./mobike_shanghai_{0}.csv".format(date), "w")
        raw_data_split_date[date].write("start_time\n")
    each_line = "{0}\n".format(start_time.split(" ")[1].split(":")[0])
    raw_data_split_date[date].write(each_line)
raw_data.close()
for date in raw_data_split_date.keys():
    raw_data_split_date[date].close()
