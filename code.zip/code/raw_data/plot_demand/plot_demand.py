#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/6/4
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


demands = np.zeros((32, 24))
for day in range(1, 32):
    data = pd.read_csv("./plot_demand/mobike_shanghai_2016-8-{0}.csv".format(day))
    for hour in range(24):
        demands[day, hour] = len(data[(data.start_time >= hour) & (data.start_time < hour + 1)])

weekday_demands = demands[list(set(range(1, 32)) - {6, 7, 13, 14, 20, 21, 27, 28}), :]
weekend_demands = demands[[6, 7, 13, 14, 20, 21, 27, 28], :]
weekday_demands = np.mean(weekday_demands, axis=0)
weekend_demands = np.mean(weekend_demands, axis=0)

with open("./plot_demand/demand.csv", "w") as f:
    f.write("时间,工作日,周末\n")
    for hour in range(24):
        f.write("{0},{1},{2}\n".format(hour, weekday_demands[hour], weekend_demands[hour]))
