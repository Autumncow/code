#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/5/20
import numpy as np
import pandas as pd
from typing import Dict
from utility import EPSFloat
from location import Location
from task import Task
from user import User
from copy import deepcopy
from mechanism.second_problem.torch_mp import TorchMP
from mechanism.second_problem.vcg_mt import VCGMT


def generate_data(task_data_file, user_data_file, user_num):
    probability = [0.75, 0.80, 0.85, 0.90, 0.95]
    # 生成task 数据
    data = pd.read_csv("raw_data/cluster_region/POI_center.csv")
    bike_num = data["bike_num"].values
    seq = np.linspace(min(bike_num), max(bike_num) + 1, 5, dtype=np.int32)
    locations2id = dict()
    tasks_data = {}
    with open(task_data_file, "w") as f:
        f.write("task_id,x,y,bike_num,value,probability\n")
        for idx in range(len(data)):
            each_data = data.iloc[idx, :]
            for idx_p in range(4, 0, -1):
                if each_data["bike_num"] >= seq[idx_p - 1]:
                    pp, p_level = probability[idx_p], idx_p
                    break
            else:
                pp, p_level = probability[0], 0
            locations2id[(int(each_data["x"] * 1000) / 1000, int(each_data["y"] * 1000) / 1000)] = int(each_data["region_id"])
            f.write("{0},{1:.3f},{2:.3f},{3},{4:.3f},{5:.2f}\n".format(int(each_data["region_id"]),
                                                                       each_data["x"], each_data["y"],
                                                                       int(each_data["bike_num"]),
                                                                       (each_data["during_time"] * each_data["bike_num"]) * 0.1, pp))
            tasks_data[int(each_data["region_id"])] = {
                "location": (each_data["x"], each_data["y"]),
                "p_level": p_level,
                "bike_num": int(each_data["bike_num"])
            }
    min_bike_num = bike_num.min()
    max_bike_num = bike_num.max()
    base_fare = [10, 20]
    unit_fare = 0.1
    radius = [3, 2, 2, 2, 1.5]  # km
    base_probability = [0.8, 1.0]
    locations = list(locations2id.keys())
    with open(user_data_file, "w") as f:
        f.write("user_id,x,y,radius,cost,tasks_id,probability\n")
        for idx in range(user_num):
            x, y = locations[np.random.randint(0, len(locations))]
            bf = np.random.randint(base_fare[0], base_fare[1] + 1)
            r = radius[tasks_data[locations2id[(x, y)]]["p_level"]]
            uf = (tasks_data[locations2id[(x, y)]]["bike_num"] - min_bike_num) / (max_bike_num - min_bike_num) * unit_fare
            tasks_id = {locations2id[(ox, oy)] for ox, oy in locations if np.sqrt(((ox - x) * 100) ** 2 + ((oy - y) * 100) ** 2) <= r}
            # 需要完成的自行车数目
            bn = sum([tasks_data[i]["bike_num"] for i in tasks_id])
            c = bn * uf + bf
            bp = np.random.uniform(base_probability[0], base_probability[1])
            f.write("{0},{1:.3f},{2:.3f},{3},{4:.5f},{5:},{6:.5f}\n".format(idx + 1, x, y, r, c, "#".join([str(i) for i in tasks_id]), bp))


def load_data(task_data_file, user_data_file):
    task_data = pd.read_csv(task_data_file)
    user_data = pd.read_csv(user_data_file)

    _tasks = []
    _users = []
    id2task = {}
    for idx in range(len(task_data)):
        each_task_data = task_data.iloc[idx, :]
        task_id = each_task_data["task_id"]
        x = each_task_data["x"]
        y = each_task_data["y"]
        value = each_task_data["value"]
        probability = each_task_data["probability"]
        task = Task(task_id, Location(EPSFloat(x), EPSFloat(y)), EPSFloat(value), EPSFloat(probability))
        id2task[task_id] = task
        _tasks.append(task)

    for idx in range(len(user_data)):
        each_user_data = user_data.iloc[idx, :]
        user_id = each_user_data["user_id"]
        x = each_user_data["x"]
        y = each_user_data["y"]
        cost = each_user_data["cost"]
        tmp_tasks = {id2task[int(task_id)]: EPSFloat(each_user_data["probability"]) for task_id in each_user_data["tasks_id"].split("#")}
        user = User(user_id, cost, tmp_tasks, Location(EPSFloat(x), EPSFloat(y)))
        _users.append(user)
    return _tasks, _users


def simulation_dispatch():
    # 生成数据
    cost_f = open("./result/cost_result1.csv", "w")
    cost_f.write("USER_NUM,TORCH,OPTIMAL\n")
    torch = TorchMP()
    vcg = VCGMT()
    for USER_NUM in [500]:
        cost_result = []
        cnt = 0
        while True:
            cost_v = []
            generate_data("./data/task_data(dispatch_with_probability).csv", "./data/user_data(dispatch_with_probability).csv", USER_NUM)
            tasks, users = load_data("./data/task_data(dispatch_with_probability).csv", "./data/user_data(dispatch_with_probability).csv")
            tasks_quality_budget: Dict[Task, EPSFloat] = {task: task.task_quality_budget for task in tasks}
            # 贪心算法检验
            flag0, selected_users0 = torch.task_dispatch(set(deepcopy(users)), deepcopy(tasks_quality_budget))
            cost_v.append(sum([user.user_cost for user in selected_users0]))

            # optimal 算法检验
            flag1, selected_users1 = vcg.task_dispatch(set(deepcopy(users)), deepcopy(tasks_quality_budget))
            cost_v.append(sum([user.user_cost for user in selected_users1]))

            if flag0 and flag1:
                cnt += 1
                print(cost_v)
                cost_result.append(cost_v)
            else:
                print("存在无法覆盖的情况")

            if cnt == 10:
                break
        print("################################")

        # 写入值的结果
        _result = np.array(cost_result)
        v0, v1 = np.mean(_result, axis=0)
        cost_f.write("{0},{1},{2}\n".format(USER_NUM, v0, v1))

    cost_f.close()


def simulation_pricing():
    # 生成数据
    torch = TorchMP()
    vcg = VCGMT()
    for USER_NUM in [850]:
        while True:
            cost_v = []
            generate_data("./data/task_data(pricing_with_probability).csv", "./data/user_data(pricing_with_probability).csv", USER_NUM)
            tasks, users = load_data("./data/task_data(pricing_with_probability).csv", "./data/user_data(pricing_with_probability).csv")
            tasks_quality_budget: Dict[Task, EPSFloat] = {task: task.task_quality_budget for task in tasks}
            # 贪心算法检验
            flag0, selected_users0 = torch.task_dispatch(set(deepcopy(users)), deepcopy(tasks_quality_budget))
            # print("dsada2")
            if not flag0:
                print("greedy存在无法覆盖的情况")
                continue
            else:
                users_utility0 = torch.user_pricing(set(deepcopy(users)), selected_users0, deepcopy(tasks_quality_budget), EPSFloat(1.0))
                cost_v.append(users_utility0)

            # optimal 算法检验
            flag1, selected_users1 = vcg.task_dispatch(set(deepcopy(users)), deepcopy(tasks_quality_budget))
            # print("dsad3")
            if not flag1:
                print("vcg 存在无法覆盖的情况")
                continue
            else:
                optimal_cost = EPSFloat(sum([user.user_cost for user in selected_users1]))
                users_utility1 = vcg.user_pricing(set(deepcopy(users)), selected_users1, deepcopy(tasks_quality_budget), optimal_cost)
                cost_v.append(users_utility1)

            if flag1 and flag0:
                # 写入值的结果
                print(cost_v)
                cost_f = open("./result/pricing_result({0}).csv".format(USER_NUM), "w")
                cost_f.write("TORCH,{0}\n".format(",".join([str(v) for v in cost_v[0].values() if v >= EPSFloat(0)])))
                cost_f.write("VCG,{0}\n".format(",".join([str(v) for v in cost_v[1].values() if v >= EPSFloat(0)])))
                cost_f.close()
                break


if __name__ == '__main__':
    simulation_dispatch()
    # simulation_pricing()



