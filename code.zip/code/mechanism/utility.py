#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/19
from typing import Set, Tuple, Dict

import numpy as np
from pyscipopt.scip import Model, quicksum

from task import Task
from user import User, NoneUser
from utility import EPSFloat, NInf, Zero


def tasks_value(tasks: Set[Task]) -> EPSFloat:
    """
    返回所有任务的价值和
    :param tasks:
    :return:
    """
    result: EPSFloat = sum([task.task_value for task in tasks])
    return result


def users_value(users: Set[User]) -> EPSFloat:
    """
    返回所有用户可以带来的价值和
    :param users:
    :return:
    """
    tasks: Set[Task] = set()
    for user in users:
        tasks = tasks | set(user.user_tasks.keys())
    return tasks_value(tasks)


def user_cost(users: Set[User]) -> EPSFloat:
    """
    返回所有用户的成本
    :param users:
    :return:
    """
    return sum([user.user_cost for user in users])


def get_tasks_num(users: Set[User]) -> int:
    s = set()
    for user in users:
        s |= set(user.user_tasks.keys())
    return len(s)


def remove_outer_budget_user(users: Set[User], budget: EPSFloat) -> Set[User]:
    return {user for user in users if user.user_cost <= budget}


def arg_max1(unselected_users: Set[User], covered_tasks: Set[Task]) -> Tuple[User, EPSFloat]:
    """
    argmax_{m_i \\in M} f_i
    :param unselected_users: 没有被选中的用户
    :param covered_tasks: 已经得到分配的任务
    :return:
    """
    optimal_user: User = NoneUser
    optimal_value: EPSFloat = NInf
    for user in unselected_users:
        marginal_user_tasks: Set[Task] = set(user.user_tasks.keys()) - covered_tasks
        if marginal_user_tasks:
            marginal_user_tasks_value: EPSFloat = EPSFloat(sum([task.task_value for task in marginal_user_tasks]))
        else:
            marginal_user_tasks_value: EPSFloat = Zero

        if marginal_user_tasks_value > optimal_value:
            optimal_user: User = user
            optimal_value: EPSFloat = marginal_user_tasks_value
    return optimal_user, optimal_value


def arg_max2(unselected_users: Set[User], covered_tasks: Set[Task]) -> Tuple[User, EPSFloat]:
    """
    argmax_{m_i \\in M} f_i / c_i
    :param unselected_users: 没有被选中的用户
    :param covered_tasks: 已经得到分配的任务
    :return:
    """
    optimal_user: User = NoneUser
    optimal_value: EPSFloat = NInf
    for user in unselected_users:
        marginal_user_tasks: Set[Task] = set(user.user_tasks.keys()) - covered_tasks
        if marginal_user_tasks:
            marginal_user_tasks_value: EPSFloat = tasks_value(marginal_user_tasks) / user.user_cost
        else:
            marginal_user_tasks_value: EPSFloat = Zero

        if marginal_user_tasks_value > optimal_value:
            optimal_user: User = user
            optimal_value: EPSFloat = marginal_user_tasks_value
    return optimal_user, optimal_value * optimal_user.user_cost


def arg_max3(unselected_users: Set[User], tasks_quality_budget: Dict[Task, EPSFloat]):
    """
    argmax_{m_i \\in M} (\\sum_{j\\in S_i} min{a_i^j Q_j}) / c_i
    :param unselected_users:
    :param tasks_quality_budget:
    :return:
    """
    optimal_user: User = NoneUser
    optimal_value: EPSFloat = NInf
    for user in unselected_users:
        temp_value = sum([min(quality, tasks_quality_budget[task]) for task, quality in user.user_tasks.items()]) / user.user_cost
        if temp_value > optimal_value:
            optimal_user = user
            optimal_value = temp_value
    return optimal_user


def set_covering_problem_optimal_solver(users: Set[User], tasks: Set[Task], budget: EPSFloat) -> Set[User]:
    """
    使用pyscipopt求解集合覆盖问题的最优解
    :param users: 用户集合
    :param tasks: 任务集合
    :param budget: 预算
    :return:
    """
    # 线性规划
    if len(users):
        is_select = {}   # 用户是否被选中
        is_covered = {}  # 任务是否被分发
        model = Model("Set Covering Problem")
        for user in users:
            is_select[user] = model.addVar(name="is_select_{0}".format(user), vtype="BINARY")
        for task in tasks:
            is_covered[task] = model.addVar(name="is_covered_{0}".format(task), vtype="BINARY")

        model.addCons(quicksum(is_select[user] * float(user.user_cost) for user in users) <= float(budget))
        for task in tasks:
            model.addCons(quicksum(is_select[user] for user in users if task in user.user_tasks) >= is_covered[task])

        model.setObjective(quicksum(float(task.task_value) * is_covered[task] for task in tasks), "maximize")
        model.hideOutput()
        model.optimize()

        if model.getStatus() == "optimal":
            return {user for user in users if int(np.round(model.getVal(is_select[user]))) == 1}
        else:
            return set()
    else:
        return set()


def GDY(users: Set[User], budget: EPSFloat) -> Set[User]:
    greedy_selected_users = set()  # 贪心算法用户分配结果
    greedy_covered_tasks = set()  # 贪心算法任务分配结果
    # 贪心分配
    while len(users):
        optimal_marginal_value_user, optimal_marginal_value = arg_max2(users, greedy_covered_tasks)
        if optimal_marginal_value_user.user_cost <= budget * optimal_marginal_value / users_value(greedy_selected_users | {optimal_marginal_value_user}):
            users.remove(optimal_marginal_value_user)
            greedy_selected_users.add(optimal_marginal_value_user)
            greedy_covered_tasks = greedy_covered_tasks | set(optimal_marginal_value_user.user_tasks.keys())
        else:
            break
    return greedy_selected_users


