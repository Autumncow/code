#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/19
from typing import Set

import numpy as np

from mechanism.utility import arg_max1, remove_outer_budget_user, GDY
from user import User
from utility import EPSFloat


class Random:

    @staticmethod
    def task_dispatch(users: Set[User], budget: EPSFloat):
        """
        BEACON机制的任务分发算法
        :param users:
        :param budget:
        :return:
        """
        # 初始化
        unselected_users = remove_outer_budget_user(users, budget)  # 贪心算法未分配出去的用户
        optimal_value_user, optimal_value = arg_max1(unselected_users, set())
        if np.random.random() < EPSFloat(0.4):
            return {optimal_value_user}
        else:
            return GDY(unselected_users, budget / 2)
