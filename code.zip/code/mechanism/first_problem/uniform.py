#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/19
from typing import Set

import numpy as np

from mechanism.utility import users_value, arg_max1, arg_max2, remove_outer_budget_user, GDY
from task import Task
from user import User
from utility import EPSFloat


class Uniform:

    @staticmethod
    def task_dispatch(users: Set[User], budget: EPSFloat):
        """
        GDY-MAX算法
        :param users:
        :param budget:
        :return:
        """
        # 获得第一个最大估值最大的用户
        unselected_users = remove_outer_budget_user(users, budget)
        optimal_value_user, optimal_value = arg_max1(unselected_users, set())
        # GDY 操作 贪心算法用户分配结果
        greedy_selected_users = GDY(unselected_users, budget / 2)
        # MAX 操作
        if optimal_value > users_value(greedy_selected_users):
            return optimal_value_user
        else:
            return greedy_selected_users

    def user_pricing(self, users: Set[User],  budget: EPSFloat):
        """
        beacon定价
        :param users: 全部的用户
        :param budget: 预算限制
        :return:
        """
        selected_users = self.task_dispatch(users, budget)
        users_payments = {}
        cost_rank = [EPSFloat(float(budget) / np.power(2, i)) for i in range(1 + int(np.log(len(users)) / np.log(2)))]
        for user_i in selected_users:
            payment = user_i.user_cost
            for cost in cost_rank:
                if cost >= user_i.user_cost:
                    payment = cost
                else:
                    payment = payment
                    break
            users_payments[user_i] = payment
        return users_payments
