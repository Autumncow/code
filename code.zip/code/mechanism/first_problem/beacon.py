#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/15
from typing import Set

from numpy import e

from mechanism.utility import users_value, arg_max1, arg_max2, remove_outer_budget_user, set_covering_problem_optimal_solver, GDY
from task import Task
from user import User
from utility import EPSFloat


class Beacon:

    @staticmethod
    def task_dispatch(users: Set[User], budget: EPSFloat):
        """
        BEACON机制的任务分发算法
        :param users:
        :param budget:
        :return:
        """
        # 获得第一个最大估值最大的用户
        unselected_users = remove_outer_budget_user(users, budget)
        # 贪心分配用户
        greedy_selected_users = GDY(unselected_users, budget / 2)
        return greedy_selected_users
        # 用LP与贪心算法的结果进行对比，确定最后结果
        # sub_users: Set[User] = remove_outer_budget_user(users, budget/2) - {optimal_value_user}
        # lp_selected_users = set_covering_problem_optimal_solver(sub_users, tasks, budget / 2)
        # return lp_selected_users
        # linear_programming_optimal_value = users_value(lp_selected_users)
        # if linear_programming_optimal_value >= (6 * e * e / (e - 1) / (e - 1)) * optimal_value:
        #     final_selected_users = greedy_selected_users
        # else:
        #     final_selected_users = {optimal_value_user}
        # return final_selected_users, optimal_value_user  # 最终的用户分配结果

    @staticmethod
    def user_pricing(users: Set[User], budget: EPSFloat):
        """
        beacon定价
        :param users: 全部的用户
        :param budget: 预算限制
        :return:
        """
        _unselected_users = remove_outer_budget_user(users, budget)
        optimal_value_user, optimal_value = arg_max1(_unselected_users, set())
        selected_users = GDY(_unselected_users, budget / 2)
        users_payments = {}
        if selected_users == {optimal_value_user}:
            users_payments[optimal_value_user] = budget
        else:
            for user_i in selected_users:
                unselected_users: Set[User] = users.copy() - {user_i}
                greedy_selected_users: Set[User] = set()
                greedy_covered_tasks: Set[Task] = set()
                user_i_payment: EPSFloat = user_i.user_cost
                while len(unselected_users):
                    optimal_marginal_value_user, optimal_marginal_value = arg_max2(unselected_users, greedy_covered_tasks)
                    user_i_marginal_value = users_value(greedy_selected_users | {user_i}) - users_value(greedy_selected_users)
                    alpha = user_i_marginal_value * optimal_marginal_value_user.user_cost / optimal_marginal_value
                    beta = user_i_marginal_value * budget / 2 / users_value(greedy_selected_users | {user_i})
                    user_i_payment = max(user_i_payment, min(alpha, beta))
                    if optimal_marginal_value_user.user_cost <= budget / 2 * optimal_marginal_value / (users_value(greedy_selected_users | {optimal_marginal_value_user})):
                        unselected_users.remove(optimal_marginal_value_user)
                        greedy_selected_users.add(optimal_marginal_value_user)
                        greedy_covered_tasks = greedy_covered_tasks | set(optimal_marginal_value_user.user_tasks.keys())
                    else:
                        break
                users_payments[user_i] = user_i_payment
        return users_payments
