#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/21
"""
这个机制没有定价过程只有分配过程
"""
from typing import Set

from mechanism.utility import users_value, arg_max1, arg_max2, remove_outer_budget_user
from user import User
from utility import EPSFloat, Zero


class Greedy:

    @staticmethod
    def task_dispatch(users: Set[User], budget: EPSFloat):
        # 初始化
        unselected_users = remove_outer_budget_user(users, budget)  # 贪心算法未分配出去的用户
        greedy_cost: EPSFloat = Zero
        greedy_selected_users = set()  # 贪心算法用户分配结果
        greedy_covered_tasks = set()  # 贪心算法任务分配结果
        optimal_value_user, optimal_value = arg_max1(unselected_users, greedy_covered_tasks)
        # 贪心分配
        while len(unselected_users):
            optimal_marginal_value_user, optimal_marginal_value = arg_max2(unselected_users, greedy_covered_tasks)
            if optimal_marginal_value_user.user_cost + greedy_cost <= budget:
                unselected_users.remove(optimal_marginal_value_user)
                greedy_selected_users.add(optimal_marginal_value_user)
                greedy_covered_tasks = greedy_covered_tasks | set(optimal_marginal_value_user.user_tasks.keys())
                greedy_cost = greedy_cost + optimal_marginal_value_user.user_cost
            else:
                break
        # MAX 操作
        if optimal_value > users_value(greedy_selected_users):
            return optimal_value_user
        else:
            return greedy_selected_users
