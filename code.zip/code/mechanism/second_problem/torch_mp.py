#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/19
from typing import Dict, Set, Tuple

import numpy as np
from copy import deepcopy
from mechanism.utility import arg_max3
from user import User, Task
from utility import EPSFloat, PInf, Zero


def is_all_tasks_covered(tasks_quality_budget: Dict[Task, EPSFloat]):
    """
    检查是否所有的任务都得到满足了
    :param tasks_quality_budget:
    :return:
    """
    for _, quality_budget in tasks_quality_budget.items():
        if quality_budget > Zero:
            return False
    else:
        return True


class TorchMP:

    @staticmethod
    def task_dispatch(unselected_users: Set[User], tasks_quality_budget: Dict[Task, EPSFloat]) -> Tuple[bool, Set[User]]:
        """
        贪心匹配，如果所有的用户都无法满足任务会返回False，
        :param unselected_users: 用户集合
        :param tasks_quality_budget: 任务预算集合
        :return:
        """
        greedy_selected_users = set()
        while not is_all_tasks_covered(tasks_quality_budget) and len(unselected_users):
            optimal_user = arg_max3(unselected_users, tasks_quality_budget)
            greedy_selected_users.add(optimal_user)
            unselected_users.remove(optimal_user)
            for task in optimal_user.user_tasks:
                tasks_quality_budget[task] = max(Zero, tasks_quality_budget[task] - optimal_user.user_tasks[task])

        if is_all_tasks_covered(tasks_quality_budget):
            return True, greedy_selected_users
        else:
            return False, set()

    @staticmethod
    def user_pricing(users: Set[User], selected_users: Set[User], tasks_quality_budget: Dict[Task, EPSFloat], alpha: EPSFloat):
        """
        :param users: 用户集合
        :param selected_users: 被选择的用户
        :param tasks_quality_budget: 任务集合
        :param alpha: 放缩因子
        :return:
        """
        selected_users_utility = {}
        for user_i in selected_users:
            tasks_quality_budget_copy = deepcopy(tasks_quality_budget)
            unselected_users = deepcopy(users)
            greedy_selected_users = set()
            critical_quality = PInf
            while not is_all_tasks_covered(tasks_quality_budget_copy) and len(unselected_users):
                optimal_user = arg_max3(unselected_users, tasks_quality_budget_copy)
                greedy_selected_users.add(optimal_user)
                unselected_users.remove(optimal_user)
                sum_quality = sum([min(tasks_quality_budget_copy[task], optimal_user.user_tasks[task]) for task in optimal_user.user_tasks])
                critical_quality = min(critical_quality, user_i.user_cost / optimal_user.user_cost * sum_quality)
                for task in optimal_user.user_tasks:
                    tasks_quality_budget_copy[task] = max(Zero, tasks_quality_budget_copy[task] - optimal_user.user_tasks[task])

            selected_users_utility[user_i] = (np.exp(-float(critical_quality)) - np.exp(-float(sum(user_i.user_tasks.values())))) * alpha
        return selected_users_utility
