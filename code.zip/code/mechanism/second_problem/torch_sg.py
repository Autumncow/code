#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/17
from typing import List, Dict, Set, Tuple

import numpy as np
from pyscipopt.scip import Model, quicksum

from user import User
from utility import EPSFloat, PInf, Zero, quality2probability


def minimize_knapsack_problem_optimal_solver(users: List[User], users_cost: Dict[User, int], users_quality: Dict[User, EPSFloat], quality_budget: EPSFloat):
    """
    使用pyscipopt求解背包问题的最优解
    :param users: 用户集合
    :param users_cost: 用户完成一个任务的成本集合
    :param users_quality: 用户完成一个任务的质量
    :param quality_budget: 一个任务的质量预算
    :return:
    """
    # 使用 LP 线性规划求解
    model = Model("Knapsack Problem")
    x = {}
    q = {}
    c = {}
    for user in users:
        x[user] = model.addVar(name="x_{0}".format(user.user_id), vtype="BINARY")
        q[user] = float(users_cost[user])
        c[user] = float(users_quality[user])

    model.addCons(quicksum(x[user] * q[user] for user in users) >= float(quality_budget))
    model.setObjective(quicksum(x[user] * c[user] for user in users), "minimize")
    model.hideOutput()
    model.optimize()
    if model.getStatus() == "optimal":
        selected_users: Set[User] = {user for user in users if int(np.round(model.getVal(x[user]))) == 1}
        selected_users_cost: EPSFloat = EPSFloat(sum([users_cost[user] for user in users if int(np.round(model.getVal(x[user]))) == 1]))
        return selected_users, selected_users_cost
    else:
        selected_users: Set[User] = set()
        selected_users_cost: EPSFloat = PInf
        return selected_users, selected_users_cost


class TorchSG:

    @staticmethod
    def task_dispatch(users: Set[User], users_cost: Dict[User, EPSFloat],
                      users_quality: Dict[User, EPSFloat], quality_budget: EPSFloat,
                      epsilon: EPSFloat = 0.01) -> Tuple[Set[User], EPSFloat, EPSFloat]:
        optimal_selected_users: Set[User] = set()
        optimal_cost: EPSFloat = PInf
        sorted_users = list(sorted(users, key=lambda x: x.user_cost))
        for k in range(len(sorted_users)):
            miu_k: EPSFloat = sorted_users[k].user_cost * epsilon / k
            users_k = sorted_users[:k + 1]
            users_cost_k = {user: int(users_cost[user] / miu_k) for user in users_k}
            users_quality_k = {user: users_quality[user] for user in users_k}
            selected_users, selected_users_cost = minimize_knapsack_problem_optimal_solver(users_k, users_cost_k, users_quality_k, quality_budget)
            if selected_users_cost * miu_k <= optimal_cost:
                optimal_selected_users = selected_users
                optimal_cost = selected_users_cost * miu_k
        optimal_quality = sum([users_quality[user] for user in optimal_selected_users])
        return optimal_selected_users, optimal_cost, optimal_quality

    def user_pricing(self, users: Set[User], selected_users: Set[User], users_cost: Dict[User, EPSFloat], users_quality: Dict[User, EPSFloat],
                     quality_budget: EPSFloat, epsilon: EPSFloat = 0.5, alpha: EPSFloat = 10) -> Dict[User, EPSFloat]:
        selected_users_utility = {}
        for user_i in selected_users:
            lower_quality = Zero  # 二分搜索
            upper_quality = quality_budget
            critical_quality = users_quality[user_i]
            back_quality = users_quality[user_i]
            while lower_quality != upper_quality:
                mid_quality = (lower_quality + upper_quality) / 2
                users_quality[user_i] = mid_quality
                optimal_selected_users, _, _ = self.task_dispatch(users, users_cost, users_quality, quality_budget, epsilon)
                if user_i in optimal_selected_users:
                    upper_quality = mid_quality
                    critical_quality = mid_quality
                else:
                    lower_quality = mid_quality
                users_quality[user_i] = back_quality

            critical_probability = quality2probability(critical_quality)
            selected_users_utility[user_i] = (quality2probability(sum(user_i.user_tasks.values())) - critical_probability) * alpha
        return selected_users_utility

    def run(self, users: Set[User], quality_budget: EPSFloat, epsilon: EPSFloat, alpha):
        users_cost = {user: user.user_cost for user in users}
        users_quality = {user: sum(user.user_tasks.values()) for user in users}
        selected_users, optimal_cost, optimal_quality = self.task_dispatch(users, users_cost, users_quality, quality_budget, epsilon)
        selected_users_utility = self.user_pricing(users, selected_users, users_cost, users_quality, quality_budget, epsilon, alpha)
        # TODO 添加评价指标
