#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/19
import numpy as np
from typing import Set, Dict, Tuple
from user import User
from pyscipopt import Model, quicksum
from utility import EPSFloat, PInf, Zero


def minimize_knapsack_problem_optimal_solver(users: Set[User], users_cost: Dict[User, EPSFloat], users_quality: Dict[User, EPSFloat], quality_budget: EPSFloat):
    """
    使用pyscipopt求解背包问题的最优解
    :param users: 用户集合
    :param users_cost: 用户完成一个任务的成本集合
    :param users_quality: 用户完成一个任务的质量
    :param quality_budget: 一个任务的质量预算
    :return:
    """
    # 使用 LP 线性规划求解
    model = Model("Knapsack Problem")
    x = {}
    q = {}
    c = {}
    for user in users:
        x[user] = model.addVar(name="x_{0}".format(user.user_id), vtype="BINARY")
        q[user] = float(users_cost[user])
        c[user] = float(users_quality[user])

    model.addCons(quicksum(x[user] * q[user] for user in users) >= float(quality_budget))
    model.setObjective(quicksum(x[user] * c[user] for user in users), "minimize")
    model.hideOutput()
    model.optimize()
    if model.getStatus() == "optimal":
        selected_users: Set[User] = {user for user in users if int(np.round(model.getVal(x[user]))) == 1}
        selected_users_cost: EPSFloat = EPSFloat(sum([users_cost[user] for user in users if int(np.round(model.getVal(x[user]))) == 1]))
        return selected_users, selected_users_cost
    else:
        selected_users: Set[User] = set()
        selected_users_cost: EPSFloat = PInf
        return selected_users, selected_users_cost


class VCGST:

    @staticmethod
    def task_dispatch(users: Set[User], users_cost: Dict[User, EPSFloat],
                      users_quality: Dict[User, EPSFloat], quality_budget: EPSFloat) -> Tuple[Set[User], EPSFloat, EPSFloat]:
        """
        使用pyscipopt求解背包问题的最优解
        :param
        users: 用户集合
        :param
        users_cost: 用户完成一个任务的成本集合
        :param
        users_quality: 用户完成一个任务的质量
        :param
        quality_budget: 一个任务的质量预算
        :return:
        """
        # 使用 LP 线性规划求解
        model = Model("Knapsack Problem")
        x = {}
        q = {}
        c = {}
        for user in users:
            x[user] = model.addVar(name="x_{0}".format(user.user_id), vtype="BINARY")
            q[user] = float(users_cost[user])
            c[user] = float(users_quality[user])

        model.addCons(quicksum(x[user] * q[user] for user in users) >= float(quality_budget))
        model.setObjective(quicksum(x[user] * c[user] for user in users), "minimize")
        model.hideOutput()
        model.optimize()
        if model.getStatus() == "optimal":
            selected_users: Set[User] = {user for user in users if int(np.round(model.getVal(x[user]))) == 1}
            selected_users_cost: EPSFloat = EPSFloat(sum([users_cost[user] for user in users if int(np.round(model.getVal(x[user]))) == 1]))
            selected_users_optimal = sum([users_quality[user] for user in selected_users])
        else:
            selected_users: Set[User] = set()
            selected_users_cost: EPSFloat = PInf
            selected_users_optimal = Zero
        return selected_users, selected_users_cost, selected_users_optimal

    def user_pricing(self, users: Set[User], selected_users: Set[User], users_cost: Dict[User, EPSFloat],
                     users_quality: Dict[User, EPSFloat], quality_budget: EPSFloat, optimal_cost: EPSFloat) -> Dict[User, EPSFloat]:
        payments = {}
        for user_i in selected_users:
            users_without_i = users.copy() - {user_i}
            optimal_selected_users_without_i, optimal_cost_without_i, optimal_quality_without_i = self.task_dispatch(users_without_i, users_cost, users_quality, quality_budget)
            payment = optimal_cost_without_i - optimal_cost
            payments[user_i] = payment
        return payments

    def run(self, users: Set[User], quality_budget: EPSFloat):
        pass
