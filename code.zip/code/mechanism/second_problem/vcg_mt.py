#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/19
import numpy as np
from typing import Set, Dict, Tuple
from user import User
from task import Task
from utility import EPSFloat
from pyscipopt import Model, quicksum


class VCGMT:

    @staticmethod
    def task_dispatch(users: Set[User], tasks_quality_budget: Dict[Task, EPSFloat]) -> Tuple[bool, Set[User]]:
        """
        使用pyscipopt求解背包问题的最优解
        :param users: 用户集合
        :param tasks_quality_budget: 任务预算集合
        :return:
        """
        # 使用 LP 线性规划求解
        model = Model("Knapsack Problem")
        x = {}
        for user in users:
            x[user] = model.addVar(name="x_{0}".format(user.user_id), vtype="BINARY")

        for task, quality_budget in tasks_quality_budget.items():
            model.addCons(quicksum(x[user] * user.user_tasks[task] for user in users if task in user.user_tasks) >= float(quality_budget))

        model.setObjective(quicksum(x[user] * user.user_cost for user in users), "minimize")
        model.hideOutput()
        model.optimize()
        if model.getStatus() == "optimal":
            selected_users: Set[User] = {user for user in users if int(np.round(model.getVal(x[user]))) == 1}
            return True, selected_users
        else:
            return False, set()

    def user_pricing(self, users: Set[User], selected_users: Set[User], tasks_quality_budget: Dict[Task, EPSFloat], optimal_cost: EPSFloat) -> Dict[User, EPSFloat]:
        payments = {}
        for user_i in selected_users:
            users_without_i = users.copy() - {user_i}
            optimal_selected_users_without_i, selected_users_without_i = self.task_dispatch(users_without_i, tasks_quality_budget)
            optimal_cost_without_i = sum(u.user_cost for u in selected_users_without_i)
            payment = optimal_cost_without_i - optimal_cost
            payments[user_i] = payment
        return payments
