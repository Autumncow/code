#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/16
from decimal import Decimal
from functools import total_ordering
from copy import deepcopy

import numpy as np


@total_ordering
class EPSFloat:
    eps: int = 5
    output_str_format = "{" + "{0}:.{1}f".format(0, eps) + "}"
    __slots__ = ["value"]

    def __init__(self, value):
        if isinstance(value, str):
            self.value: Decimal = Decimal(value)
        elif isinstance(value, int):
            self.value: Decimal = Decimal(value)
        elif isinstance(value, float):
            self.value: Decimal = Decimal(str(np.round(value, self.eps)))
        elif isinstance(value, Decimal):
            self.value: Decimal = value
        elif isinstance(value, EPSFloat):
            self.value: Decimal = deepcopy(value.value)
        else:
            raise Exception("除了str, float, int, Decimal EPSFloat，不支持其他类型")

    def __repr__(self):
        return self.output_str_format.format(self.value)

    def __add__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            x: float = np.round(float(self.value + Decimal(str(np.round(other, self.eps)))), self.eps)
        elif isinstance(other, Decimal):
            x: float = np.round(float(self.value + other), self.eps)
        elif isinstance(other, EPSFloat):
            x: float = np.round(float(self.value + other.value), self.eps)
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")
        return EPSFloat(x)

    def __radd__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            x: float = np.round(float(self.value + Decimal(str(np.round(other, self.eps)))), self.eps)
        elif isinstance(other, Decimal):
            x: float = np.round(float(self.value + other), self.eps)
        elif isinstance(other, EPSFloat):
            x: float = np.round(float(self.value + other.value), self.eps)
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")
        return EPSFloat(x)

    def __sub__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            x: float = np.round(float(self.value - Decimal(str(np.round(other, self.eps)))), self.eps)
        elif isinstance(other, Decimal):
            x: float = np.round(float(self.value - other), self.eps)
        elif isinstance(other, EPSFloat):
            x: float = np.round(float(self.value - other.value), self.eps)
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")
        return EPSFloat(x)

    def __rsub__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            x: float = np.round(float(Decimal(str(np.round(other, self.eps))) - self.value), self.eps)
        elif isinstance(other, Decimal):
            x: float = np.round(float(other - self.value), self.eps)
        elif isinstance(other, EPSFloat):
            x: float = np.round(float(other.value - self.value), self.eps)
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")
        return EPSFloat(x)

    def __truediv__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            x: float = np.round(float(self.value / Decimal(str(np.round(other, self.eps)))), self.eps)
        elif isinstance(other, Decimal):
            x: float = np.round(float(self.value / other), self.eps)
        elif isinstance(other, EPSFloat):
            x: float = np.round(float(self.value / other.value), self.eps)
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")
        return EPSFloat(x)

    def __rtruediv__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            x: float = np.round(float(Decimal(str(np.round(other, self.eps))) / self.value), self.eps)
        elif isinstance(other, Decimal):
            x: float = np.round(float(other / self.value), self.eps)
        elif isinstance(other, EPSFloat):
            x: float = np.round(float(other.value / self.value), self.eps)
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")
        return EPSFloat(x)

    def __mul__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            x: float = np.round(float(self.value * Decimal(str(np.round(other, self.eps)))), self.eps)
        elif isinstance(other, Decimal):
            x: float = np.round(float(self.value * other), self.eps)
        elif isinstance(other, EPSFloat):
            x: float = np.round(float(self.value * other.value), self.eps)
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")
        return EPSFloat(x)

    def __rmul__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            x: float = np.round(float(self.value * Decimal(str(np.round(other, self.eps)))), self.eps)
        elif isinstance(other, Decimal):
            x: float = np.round(float(self.value * other), self.eps)
        elif isinstance(other, EPSFloat):
            x: float = np.round(float(self.value * other.value), self.eps)
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")
        return EPSFloat(x)

    def __abs__(self):
        return EPSFloat(float(abs(self.value)))

    def __lt__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return self.value < Decimal(str(np.round(other, self.eps)))
        elif isinstance(other, Decimal):
            return self.value < other
        elif isinstance(other, EPSFloat):
            return self.value < other.value
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")

    def __eq__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return self.value == Decimal(str(np.round(other, self.eps)))
        elif isinstance(other, Decimal):
            return self.value == other
        elif isinstance(other, EPSFloat):
            return self.value == other.value
        else:
            raise Exception("不可以处理float, int, decimal, EPSFloat以外其他类型的数据")

    def __float__(self):
        return float(self.value)

    def __bool__(self):
        return self.value != 0

    def __int__(self):
        return int(self.value)


Zero = EPSFloat(0.0)
One = EPSFloat(1.0)
PInf = EPSFloat(np.inf)
NInf = EPSFloat(-np.inf)


def probability2quality(probability: EPSFloat) -> EPSFloat:
    if float(probability) == 1.0:
        return NInf
    else:
        return EPSFloat(-1 * np.log(1 - float(probability)))


def quality2probability(quality: EPSFloat) -> EPSFloat:
    return EPSFloat(1 - np.exp(-float(quality)))


if __name__ == '__main__':
    a = EPSFloat(0)
    if a:
        print("dsadad")
    else:
        print("hee")
    a = 'dsada'
    print(a)
    print(type(sum([EPSFloat(1), EPSFloat(2)]) + sum([])))
