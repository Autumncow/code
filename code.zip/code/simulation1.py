#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/5/16
import numpy as np
import pandas as pd
from utility import EPSFloat
from location import Location
from task import Task
from user import User
from copy import deepcopy
from mechanism.utility import users_value
from mechanism.utility import set_covering_problem_optimal_solver
from mechanism.first_problem.beacon import Beacon
from mechanism.first_problem.uniform import Uniform
from mechanism.first_problem.random import Random
from mechanism.first_problem.greedy import Greedy
from mechanism.utility import get_tasks_num


def generate_data(task_data_file, user_data_file, user_num):
    probability = [0.75, 0.80, 0.85, 0.90, 0.95]
    # 生成task 数据
    data = pd.read_csv("raw_data/cluster_region/POI_center.csv")
    bike_num = data["bike_num"].values
    seq = np.linspace(min(bike_num), max(bike_num) + 1, 5, dtype=np.int32)
    locations2id = dict()
    tasks_data = {}
    with open(task_data_file, "w") as f:
        f.write("task_id,x,y,bike_num,value,probability\n")
        for idx in range(len(data)):
            each_data = data.iloc[idx, :]
            for idx_p in range(4, 0, -1):
                if each_data["bike_num"] >= seq[idx_p - 1]:
                    pp, p_level = probability[idx_p], idx_p
                    break
            else:
                pp, p_level = probability[0], 0
            locations2id[(int(each_data["x"] * 1000) / 1000, int(each_data["y"] * 1000) / 1000)] = int(each_data["region_id"])
            f.write("{0},{1:.3f},{2:.3f},{3},{4:.3f},{5:.2f}\n".format(int(each_data["region_id"]),
                                                                       each_data["x"], each_data["y"],
                                                                       int(each_data["bike_num"]),
                                                                       (each_data["during_time"] * each_data["bike_num"]) * 0.1, pp))
            tasks_data[int(each_data["region_id"])] = {
                "location": (each_data["x"], each_data["y"]),
                "p_level": p_level,
                "bike_num": int(each_data["bike_num"])
            }
    min_bike_num = bike_num.min()
    max_bike_num = bike_num.max()
    base_fare = [10, 20]
    unit_fare = 0.1
    radius = [3.5, 3, 2, 2, 1.5]  # km
    base_probability = [0.8, 1.0]
    locations = list(locations2id.keys())
    with open(user_data_file, "w") as f:
        f.write("user_id,x,y,radius,cost,tasks_id,probability\n")
        for idx in range(user_num):
            x, y = locations[np.random.randint(0, len(locations))]
            bf = np.random.randint(base_fare[0], base_fare[1] + 1)
            r = radius[tasks_data[locations2id[(x, y)]]["p_level"]]
            uf = (tasks_data[locations2id[(x, y)]]["bike_num"] - min_bike_num) / (max_bike_num - min_bike_num) * unit_fare
            tasks_id = {locations2id[(ox, oy)] for ox, oy in locations if np.sqrt(((ox - x) * 100) ** 2 + ((oy - y) * 100) ** 2) <= r}
            # 需要完成的自行车数目
            bn = sum([tasks_data[i]["bike_num"] for i in tasks_id])
            c = bn * uf + bf
            bp = np.random.uniform(base_probability[0], base_probability[1])
            f.write("{0},{1:.3f},{2:.3f},{3},{4:.5f},{5:},{6:.5f}\n".format(idx + 1, x, y, r, c, "#".join([str(i) for i in tasks_id]), bp))


def load_data(task_data_file, user_data_file):
    task_data = pd.read_csv(task_data_file)
    user_data = pd.read_csv(user_data_file)

    _tasks = []
    _users = []
    id2task = {}
    for idx in range(len(task_data)):
        each_task_data = task_data.iloc[idx, :]
        task_id = each_task_data["task_id"]
        x = each_task_data["x"]
        y = each_task_data["y"]
        value = each_task_data["value"]
        probability = each_task_data["probability"]
        task = Task(task_id, Location(EPSFloat(x), EPSFloat(y)), EPSFloat(value), EPSFloat(probability))
        id2task[task_id] = task
        _tasks.append(task)

    for idx in range(len(user_data)):
        each_user_data = user_data.iloc[idx, :]
        user_id = each_user_data["user_id"]
        x = each_user_data["x"]
        y = each_user_data["y"]
        cost = each_user_data["cost"]
        tmp_tasks = {id2task[int(task_id)]: EPSFloat(each_user_data["probability"]) for task_id in each_user_data["tasks_id"].split("#")}
        user = User(user_id, cost, tmp_tasks, Location(EPSFloat(x), EPSFloat(y)))
        _users.append(user)
    return _tasks, _users


def simulation_dispatch_fixed_budget():
    # 生成数据
    value_f = open("result/value_result_fixed_budget.csv", "w")
    ratio_f = open("result/ratio_result_fixed_budget.csv", "w")
    covered_f = open("result/covered_result_fixed_budget.csv", "w")
    value_f.write("USER_NUM,BUDGET,GDY,OPTIMAL,BEACON,UNIFORM\n")
    ratio_f.write("USER_NUM,BUDGET,GDY,OPTIMAL,BEACON,UNIFORM\n")
    covered_f.write("USER_NUM,BUDGET,GDY,OPTIMAL,BEACON,UNIFORM\n")
    beacon = Beacon()
    random = Random()
    greedy = Greedy()
    for USER_NUM in [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600]:  # [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600] / [300]
        for BUDGET in [1000]:  # [1000] / [500, 750, 1000, 1250, 1500, 1750, 2000]
            value_result = []
            ratio_result = []
            covered_result = []
            for _ in range(20):
                value_v = []
                ratio_v = []
                covered_v = []
                generate_data("./data/task_data(dispatch_fixed_budget).csv", "./data/user_data(dispatch_fixed_budget).csv", USER_NUM)
                tasks, users = load_data("./data/task_data(dispatch_fixed_budget).csv", "./data/user_data(dispatch_fixed_budget).csv")
                tasks_num = len(tasks)
                # 贪心算法检验
                selected_users0 = greedy.task_dispatch(set(deepcopy(users)), EPSFloat(BUDGET / 2))
                value_v.append(users_value(selected_users0))
                ratio_v.append(len(selected_users0) / USER_NUM)
                covered_v.append(get_tasks_num(selected_users0) / tasks_num)

                # optimal 算法检验
                selected_users1 = set_covering_problem_optimal_solver(set(deepcopy(users)), set(deepcopy(tasks)), EPSFloat(BUDGET / 2))
                value_v.append(users_value(selected_users1))
                ratio_v.append(len(selected_users1) / USER_NUM)
                covered_v.append(get_tasks_num(selected_users1) / tasks_num)
                # beacon 算法检验
                selected_users2 = beacon.task_dispatch(set(deepcopy(users)), EPSFloat(2 * BUDGET))
                value_v.append(users_value(selected_users2))
                ratio_v.append(len(selected_users2) / USER_NUM)
                covered_v.append(get_tasks_num(selected_users2) / tasks_num)
                # random 算法检验
                selected_users3 = random.task_dispatch(set(deepcopy(users)), EPSFloat(2 * BUDGET))
                value_v.append(users_value(selected_users3))
                ratio_v.append(len(selected_users3) / USER_NUM)
                covered_v.append(get_tasks_num(selected_users3) / tasks_num)

                value_result.append(value_v)
                ratio_result.append(ratio_v)
                covered_result.append(covered_v)
                print("[{0}, {1}, {2}]\n".format(value_v, ratio_v, covered_v))
            print("################################")

            # 写入值的结果
            _result = np.array(value_result)
            v0, v1, v2, v3 = np.mean(_result, axis=0)
            value_f.write("{0},{1},{2},{3},{4},{5}\n".format(USER_NUM, BUDGET, v0, v1, v2, v3))
            # 写入比例的结果
            _result = np.array(ratio_result)
            v0, v1, v2, v3 = np.mean(_result, axis=0)
            ratio_f.write("{0},{1},{2},{3},{4},{5}\n".format(USER_NUM, BUDGET, v0, v1, v2, v3))
            # 写入覆盖率的结果
            _result = np.array(covered_result)
            v0, v1, v2, v3 = np.mean(_result, axis=0)
            covered_f.write("{0},{1},{2},{3},{4},{5}\n".format(USER_NUM, BUDGET, v0, v1, v2, v3))

    value_f.close()
    ratio_f.close()
    covered_f.close()


def simulation_dispatch_fixed_user():
    value_f = open("result/value_result_fixed_user.csv", "w")
    ratio_f = open("result/ratio_result_fixed_user.csv", "w")
    covered_f = open("result/covered_result_fixed_user.csv", "w")
    value_f.write("USER_NUM,BUDGET,GDY,OPTIMAL,BEACON,UNIFORM\n")
    ratio_f.write("USER_NUM,BUDGET,GDY,OPTIMAL,BEACON,UNIFORM\n")
    covered_f.write("USER_NUM,BUDGET,GDY,OPTIMAL,BEACON,UNIFORM\n")
    beacon = Beacon()
    random = Random()
    greedy = Greedy()
    for USER_NUM in [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600]:  # [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600] / [300]
        for BUDGET in [1000]:  # [1000] / [500, 750, 1000, 1250, 1500, 1750, 2000]
            value_result = []
            ratio_result = []
            covered_result = []
            for _ in range(20):
                value_v = []
                ratio_v = []
                covered_v = []
                generate_data("./data/task_data(dispatch_fixed_user).csv", "./data/user_data(dispatch_fixed_user).csv", USER_NUM)
                tasks, users = load_data("./data/task_data(dispatch_fixed_user).csv", "./data/user_data(dispatch_fixed_user).csv")
                tasks_num = len(tasks)
                # 贪心算法检验
                selected_users0 = greedy.task_dispatch(set(deepcopy(users)), EPSFloat(BUDGET / 2))
                value_v.append(users_value(selected_users0))
                ratio_v.append(len(selected_users0) / USER_NUM)
                covered_v.append(get_tasks_num(selected_users0) / tasks_num)

                # optimal 算法检验
                selected_users1 = set_covering_problem_optimal_solver(set(deepcopy(users)), set(deepcopy(tasks)), EPSFloat(BUDGET / 2))
                value_v.append(users_value(selected_users1))
                ratio_v.append(len(selected_users1) / USER_NUM)
                covered_v.append(get_tasks_num(selected_users1) / tasks_num)
                # beacon 算法检验
                selected_users2 = beacon.task_dispatch(set(deepcopy(users)), EPSFloat(2 * BUDGET))
                value_v.append(users_value(selected_users2))
                ratio_v.append(len(selected_users2) / USER_NUM)
                covered_v.append(get_tasks_num(selected_users2) / tasks_num)
                # uniform 算法检验
                selected_users3 = random.task_dispatch(set(deepcopy(users)), EPSFloat(2 * BUDGET))
                value_v.append(users_value(selected_users3))
                ratio_v.append(len(selected_users3) / USER_NUM)
                covered_v.append(get_tasks_num(selected_users3) / tasks_num)

                value_result.append(value_v)
                ratio_result.append(ratio_v)
                covered_result.append(covered_v)
                print("[{0}, {1}, {2}]\n".format(value_v, ratio_v, covered_v))
            print("################################")

            # 写入值的结果
            _result = np.array(value_result)
            v0, v1, v2, v3 = np.mean(_result, axis=0)
            value_f.write("{0},{1},{2},{3},{4},{5}\n".format(USER_NUM, BUDGET, v0, v1, v2, v3))
            # 写入比例的结果
            _result = np.array(ratio_result)
            v0, v1, v2, v3 = np.mean(_result, axis=0)
            ratio_f.write("{0},{1},{2},{3},{4},{5}\n".format(USER_NUM, BUDGET, v0, v1, v2, v3))
            # 写入覆盖率的结果
            _result = np.array(covered_result)
            v0, v1, v2, v3 = np.mean(_result, axis=0)
            covered_f.write("{0},{1},{2},{3},{4},{5}\n".format(USER_NUM, BUDGET, v0, v1, v2, v3))

    value_f.close()
    ratio_f.close()
    covered_f.close()


def simulation_pricing_fixed_budget():
    value_f = open("./result/pricing_result_fixed_budget.csv", "w")
    value_f.write("USER_NUM,BUDGET,"
                  "BEACON(USER_NUM),UNIFORM(USER_NUM),"
                  "BEACON(PAYMENT AVERAGE),UNIFORM(PAYMENT AVERAGE),"
                  "BEACON(PAYMENT TOTAL),UNIFORM(PAYMENT TOTAL),"
                  "BEACON(UTILITY AVERAGE),UNIFORM(UTILITY AVERAGE),"
                  "BEACON(UTILITY TOTAL),UNIFORM(UTILITY TOTAL)\n")
    beacon = Beacon()
    uniform = Uniform()
    for USER_NUM in [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600]:  # [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600] / [300]
        for BUDGET in [1000]:  # [1000] / [500, 750, 1000, 1250, 1500, 1750, 2000]
            value_result_fixed_budget = []
            for _ in range(10):
                value_v = []
                generate_data("./data/task_data(pricing_fixed_budget).csv", "./data/user_data(pricing_fixed_budget).csv", USER_NUM)
                tasks, users = load_data("./data/task_data(pricing_fixed_budget).csv", "./data/user_data(pricing_fixed_budget).csv")
                # beacon 算法检验
                payments1 = beacon.user_pricing(set(deepcopy(users)), EPSFloat(2 * BUDGET))
                # uniform 算法检验
                payments2 = uniform.user_pricing(set(deepcopy(users)), EPSFloat(2 * BUDGET))
                value_v.append(len(payments1))
                value_v.append(len(payments2))
                value_v.append(sum([payment for _, payment in payments1.items()]) / len(payments1))
                value_v.append(sum([payment for _, payment in payments2.items()]) / len(payments2))
                value_v.append(sum([payment for _, payment in payments1.items()]))
                value_v.append(sum([payment for _, payment in payments2.items()]))
                value_v.append(sum([payment - user.user_cost for user, payment in payments1.items()]) / len(payments1))
                value_v.append(sum([payment - user.user_cost for user, payment in payments2.items()]) / len(payments2))
                value_v.append(sum([payment - user.user_cost for user, payment in payments1.items()]))
                value_v.append(sum([payment - user.user_cost for user, payment in payments2.items()]))
                print(value_v)
                value_result_fixed_budget.append(value_v)
            print("################################")
            # 写入值的结果
            _result = np.array(value_result_fixed_budget)
            v1, v2, v3, v4, v5, v6, v7, v8, v9, v10 = np.mean(_result, axis=0)
            value_f.write("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}\n".format(USER_NUM, BUDGET, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10))

    value_f.close()


def simulation_pricing_fixed_user():
    value_f = open("./result/pricing_result_fixed_user.csv", "w")
    value_f.write("USER_NUM,BUDGET,"
                  "BEACON(USER_NUM),UNIFORM(USER_NUM),"
                  "BEACON(PAYMENT AVERAGE),UNIFORM(PAYMENT AVERAGE),"
                  "BEACON(PAYMENT TOTAL),UNIFORM(PAYMENT TOTAL),"
                  "BEACON(UTILITY AVERAGE),UNIFORM(UTILITY AVERAGE),"
                  "BEACON(UTILITY TOTAL),UNIFORM(UTILITY TOTAL)\n")
    beacon = Beacon()
    uniform = Uniform()
    for USER_NUM in [300]:  # [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600] / [300]
        for BUDGET in [500, 750, 1000, 1250, 1500, 1750, 2000]:  # [1000] / [500, 750, 1000, 1250, 1500, 1750, 2000]
            value_result_fixed_user = []
            for _ in range(10):
                value_v = []
                generate_data("./data/task_data(pricing_fixed_user).csv", "./data/user_data(pricing_fixed_user).csv", USER_NUM)
                tasks, users = load_data("./data/task_data(pricing_fixed_user).csv", "./data/user_data(pricing_fixed_user).csv")
                # beacon 算法检验
                payments1 = beacon.user_pricing(set(deepcopy(users)), EPSFloat(2 * BUDGET))
                # uniform 算法检验
                payments2 = uniform.user_pricing(set(deepcopy(users)), EPSFloat(2 * BUDGET))
                value_v.append(len(payments1))
                value_v.append(len(payments2))
                value_v.append(sum([payment for _, payment in payments1.items()]) / len(payments1))
                value_v.append(sum([payment for _, payment in payments2.items()]) / len(payments2))
                value_v.append(sum([payment for _, payment in payments1.items()]))
                value_v.append(sum([payment for _, payment in payments2.items()]))
                value_v.append(sum([payment - user.user_cost for user, payment in payments1.items()]) / len(payments1))
                value_v.append(sum([payment - user.user_cost for user, payment in payments2.items()]) / len(payments2))
                value_v.append(sum([payment - user.user_cost for user, payment in payments1.items()]))
                value_v.append(sum([payment - user.user_cost for user, payment in payments2.items()]))
                print(value_v)
                value_result_fixed_user.append(value_v)
            print("################################")
            # 写入值的结果
            _result = np.array(value_result_fixed_user)
            v1, v2, v3, v4, v5, v6, v7, v8, v9, v10 = np.mean(_result, axis=0)
            value_f.write("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}\n".format(USER_NUM, BUDGET, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10))

    value_f.close()


if __name__ == '__main__':
    simulation_dispatch_fixed_budget()
    # simulation_dispatch_fixed_user()
    # simulation_pricing_fixed_budget()
    # simulation_pricing_fixed_user()



