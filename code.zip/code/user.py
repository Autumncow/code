#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/16
from typing import Dict

from location import Location, NoneLocation
from task import Task
from utility import EPSFloat, Zero, probability2quality


class User:
    __slots__ = ["_user_id", "_user_cost", "_user_tasks", "_user_location", "_user_payment"]

    def __init__(self, user_id: int, cost: EPSFloat, tasks: Dict[Task, EPSFloat], user_location: Location):
        """

        :param user_id: 用户id
        :param cost:  用户投标成本
        :param tasks: 用户投标任务 {task : probability}
        :param user_location: 用户所在位置
        """
        self._user_id: int = user_id
        self._user_cost: EPSFloat = cost
        self._user_location: Location = user_location
        self._user_tasks: Dict[Task, EPSFloat] = {task: probability2quality(probability) for task, probability in tasks.items()}  # 任务和完成任务的概率以及共享
        self._user_payment: EPSFloat = EPSFloat(0.0)  # 平台对用户的支付

    @property
    def user_id(self) -> int:
        return self._user_id

    @property
    def user_cost(self) -> EPSFloat:
        return self._user_cost

    @property
    def user_location(self) -> Location:
        return self._user_location

    @property
    def user_tasks(self) -> Dict[Task, EPSFloat]:
        return self._user_tasks

    @property
    def user_payment(self) -> EPSFloat:
        return self._user_payment

    @user_payment.setter
    def user_payment(self, payment: EPSFloat):
        self._user_payment = payment

    def add_task(self, task: Task, quality: EPSFloat):
        self._user_tasks[task] = quality

    def __eq__(self, other):
        return self._user_id == other.user_id

    def __hash__(self):
        return hash(self._user_id)

    def __repr__(self):
        return "{0}".format(self._user_id)

    def __bool__(self):
        return self._user_id != 0


NoneUser = User(0, Zero, dict(), NoneLocation)
if __name__ == '__main__':
    a = User(1, Zero, dict(), NoneLocation)
    a.user_payment = 10
    print(a.user_payment)
