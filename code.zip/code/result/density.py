#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/6/3
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')

fig_size = (8, 6)
fontsize = 16
chinese_font = {"family": "SimSun", "weight": "normal", "size": fontsize}
english_font = {"family": "Times New Roman", "weight": "normal", "size": fontsize}
label1 = "BMTCMP"
label2 = "VCG"
line_width = 2
sample_num = 45

with open("./250.txt", "r") as f:
    torch_data = []
    vcg_data = []
    cnt = 0
    for line in f:
        if cnt == 0:
            cnt += 1
            continue
        each_data = line.split(',')
        if len(each_data) == 1:
            torch_data.append(float(each_data[0]))
        else:
            torch_data.append(float(each_data[0]) * 4.090834013)
            vcg_data.append(float(each_data[1]))

    torch_data = np.array(list(sorted((torch_data + torch_data))))
    vcg_data = np.array(list(sorted(vcg_data + vcg_data)))

    figure, ax = plt.subplots(figsize=fig_size)
    plt.subplots_adjust(left=0.1, bottom=0.1, right=0.95, top=0.95, hspace=0.1, wspace=0.1)

    kde = stats.gaussian_kde(torch_data)
    x = np.linspace(np.min(vcg_data), np.max(vcg_data) / 2, sample_num)
    p = kde(x)
    p1 = p / np.sum(p)
    torch, = plt.plot(x, p1, "r--", label=label1, linewidth=line_width)

    kde = stats.gaussian_kde(vcg_data)
    x = np.linspace(np.min(vcg_data), np.max(vcg_data) / 2, sample_num)
    p = kde(x)
    p2 = p / np.sum(p)
    vcg, = plt.plot(x, p2, "b-.", label=label2, linewidth=line_width)
    with open("./250_density.csv", "w") as df:
        df.write("期望效用,BMTCMP,VCG\n")
        for i in range(len(p)):
            df.write("{0},{1},{2}\n".format(x[i], p1[i], p2[i]))

    legend = plt.legend(handles=[torch, vcg], prop=english_font)
    labels = ax.get_xticklabels() + ax.get_yticklabels()
    [label.set_fontname('Times New Roman') for label in labels]
    [label.set_fontsize(fontsize) for label in labels]
    plt.ylabel("频率", chinese_font)
    plt.xlabel("期望效用", chinese_font)
    plt.savefig("./250.png")
    plt.show()


with open("./700.txt", "r") as f:
    torch_data = []
    vcg_data = []
    cnt = 0
    for line in f:
        if cnt == 0:
            cnt += 1
            continue
        each_data = line.split(',')
        if len(each_data) == 1:
            torch_data.append(float(each_data[0]))
        else:
            torch_data.append(float(each_data[0]) * 1.886702371)
            vcg_data.append(float(each_data[1]))

    torch_data = np.array(list(sorted((torch_data + torch_data))))
    vcg_data = np.array(list(sorted(vcg_data + vcg_data)))

    figure, ax = plt.subplots(figsize=fig_size)
    plt.subplots_adjust(left=0.1, bottom=0.1, right=0.95, top=0.95, hspace=0.1, wspace=0.1)

    kde = stats.gaussian_kde(torch_data)
    x = np.linspace(np.min(vcg_data), np.max(vcg_data) / 2, sample_num)
    p = kde(x)
    p1 = p / np.sum(p)
    torch, = plt.plot(x, p1, "r--", label=label1, linewidth=line_width)

    kde = stats.gaussian_kde(vcg_data)
    x = np.linspace(np.min(vcg_data), np.max(vcg_data) / 2, sample_num)
    p = kde(x)
    p2 = p / np.sum(p)
    vcg, = plt.plot(x, p2, "b-.", label=label2, linewidth=line_width)
    with open("./700_density.csv", "w") as df:
        df.write("期望效用,BMTCMP,VCG\n")
        for i in range(len(p)):
            df.write("{0},{1},{2}\n".format(x[i], p1[i], p2[i]))

    legend = plt.legend(handles=[torch, vcg], prop=english_font)
    labels = ax.get_xticklabels() + ax.get_yticklabels()
    [label.set_fontname('Times New Roman') for label in labels]
    [label.set_fontsize(fontsize) for label in labels]
    plt.ylabel("频率", chinese_font)
    plt.xlabel("期望效用", chinese_font)
    plt.savefig("./700.png")
    plt.show()
