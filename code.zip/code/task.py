#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/16
from location import Location, NoneLocation
from utility import EPSFloat, Zero, probability2quality


class Task:

    __slots__ = ["_task_id", "_task_location", "_task_value", "_task_quality_budget"]

    def __init__(self, task_id: int, location: Location, value: EPSFloat, task_probability_budget: EPSFloat):
        self._task_id: int = task_id
        self._task_location: Location = location   # 任务的地点
        self._task_value: EPSFloat = value         # 完成任务的价值
        self._task_quality_budget: EPSFloat = probability2quality(task_probability_budget)  # 完成任务的预算

    @property
    def task_id(self) -> int:
        return self._task_id

    @property
    def task_location(self) -> Location:
        return self._task_location

    @property
    def task_value(self) -> EPSFloat:
        return self._task_value

    @property
    def task_quality_budget(self) -> EPSFloat:
        return self._task_quality_budget

    def __repr__(self):
        return "{0},{1},{2},{3}".format(self._task_id, self._task_location, self._task_value, self._task_quality_budget)
        # return "{0}".format(self.task_id)

    def __eq__(self, other):
        return self._task_id == other.task_id

    def __hash__(self):
        return hash(self._task_id)

    def __bool__(self):
        return self._task_id != 0


NoneTask = Task(0, NoneLocation, Zero, Zero)
