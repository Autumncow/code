#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/18

from pyscipopt import Model, quicksum

budget = 20
population = {
    0: 523, 1: 690, 2: 420,
    3: 1010, 4: 1200, 5: 850,
    6: 400, 7: 1008, 8: 950
}

coverage = {
    0: {0, 1, 5},
    1: {0, 7, 8},
    2: {2, 3, 4, 6},
    3: {2, 5, 6},
    4: {0, 2, 6, 7, 8},
    5: {3, 4, 8}
}
cost = {
    0: 4.2,
    1: 6.1,
    2: 5.2,
    3: 5.5,
    4: 4.8,
    5: 9.2
}

m = Model("cell_tower")
build, is_covered = {}, {}
for i in range(6):
    build[i] = m.addVar(name="build_{0}".format(i), vtype="BINARY")
for j in range(9):
    is_covered[j] = m.addVar(name="is_covered_{0}".format(j), vtype="BINARY")

for j in range(9):
    m.addCons(quicksum(build[i] for i in range(6) if j in coverage[i]) >= is_covered[j])

m.addCons(quicksum(build[i] * cost[i] for i in range(6)) <= budget, name="budget")
m.setObjective(quicksum(is_covered[j] * population[j] for j in range(9)), "maximize")
m.optimize()

total_cost = 0
for i in range(6):
    if int(m.getVal(build[i])) == 1:
        print(f"\n Build a cell tower at location Tower {i}.")
        total_cost += int(m.getVal(build[i])) * cost[i]

total_population = 0
covered_population = 0
for j in range(9):
    total_population += population[j]
    covered_population += int(m.getVal(is_covered[j])) * population[j]


coverage = round(covered_population/total_population*100, 2)
print(f"\n The population coverage associated to the cell towers build plan is: {coverage} %")

budget_consumption = round(100*total_cost/budget, 2)
print(f"\n The percentage of budget consumed associated to the cell towers build plan is: {budget_consumption} %")
