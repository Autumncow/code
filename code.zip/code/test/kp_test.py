#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/20
import numpy as np
from pyscipopt import Model, quicksum

m = Model("KP")
x = {}
w = {}
v = {}
for i in range(50):
    x[i] = m.addVar(name="x{0}".format(i), vtype="BINARY")
    w[i] = float(np.random.random() * 10)
    v[i] = float(np.random.random() * 10)

B = 50 * 10 / 3
m.addCons(quicksum(x[i] * w[i] for i in range(50)) <= B)
m.setObjective(quicksum(x[i] * v[i] for i in range(50)), "maximize")
m.hideOutput()
m.optimize()

if m.getStatus() == "optimal":
    print("success")
else:
    print("false")
