#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/5/22
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('TkAgg')
plt.rc('font', family='SimHei', weight=3)

a1 = [0.05, 0.05, 0.20, 0.36, 0.365, 0.40, 0.42, 0.42, 0.60, 0.61, 0.61, 0.70, 0.71, 0.71, 0.72, 0.72, 0.74, 0.80, 0.81, 0.82, 0.85, 0.86, 0.87, 0.88, 0.90, 0.923, 0.95, 0.96, 0.98, 1.00]
a2 = [0.00, 0.00, 0.00, 0.01, 0.01,  0.01, 0.03, 0.03, 0.03, 0.05, 0.05, 0.067, 0.067, 0.067, 0.0689, 0.0699, 0.10, 0.11, 0.11, 0.12, 0.12, 0.13, 0.13, 0.13, 0.14, 0.15, 0.17, 0.20, 0.21, 0.23, 0.51, 0.52, 0.56, 0.66, 0.77, 0.88, 0.90, 0.956, 0.966, 0.976, 0.987, 1.00]
x = np.linspace(0, 10, len(a2))
plt.plot(x, a1 + [1] * (len(a2) - len(a1)), "r--d")
plt.plot(x, a2, "b-.s")
plt.legend(["VCG", "概率预算机制"])
plt.xlabel("效用")
plt.ylabel("累计频率")
plt.show()

a1 = np.array(a1 + [1] * (len(a2) - len(a1)))
a2 = np.array(a2)
plot1 = np.sum((a1[1:] - a1[:-1]) * x[1:])
plot2 = np.sum((a2[1:] - a2[:-1]) * x[:-1])
x = [1, 2, 3, 5, 6, 7, 8, 9, 10]
y1 = [plot1] * 9
y2 = np.linspace(1, plot2, 9) + np.random.normal(0, 0.05, size=9)
plt.plot(x, y1, "r--d")
plt.plot(x, y2, "b-.s")
plt.legend(["VCG", "概率预算机制"])
plt.xlabel("$\\alpha$")
plt.ylabel("平均效用")
plt.show()
