#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/26
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial import ConvexHull

points = np.random.rand(10, 2)  # 30 random points in 2-D
hull = ConvexHull(points)

plt.plot(points[:, 0], points[:, 1], 'o')
for simplex in hull.simplices:
    plt.plot(points[simplex, 0], points[simplex, 1], 'k-')
plt.show()
