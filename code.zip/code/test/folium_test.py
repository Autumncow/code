#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/27
import webbrowser

import folium
import pandas as pd
import numpy as np
from folium.plugins import HeatMap

# 数据导入：
full = pd.read_csv("../raw_data/cluster_region/POI_center.csv")

# 创建地图对象：
schools_map = folium.Map(location=[full['y'].mean(), full['x'].mean()], zoom_start=10)
# marker_cluster = plugins.MarkerCluster().add_to(schools_map)

# 标注数据点：
# for name, row in full.iterrows():
#     folium.Marker([row["x"], row["y"]], popup="{0}:{1}".format(row["cities"], row["GDP"])).add_to(marker_cluster)
# 逐行读取经纬度，数值，并且打点
# folium.RegularPolygonMarker([row["lat"], row["lon"]], popup="{0}:{1}".format(row["cities"], row["GDP"]),number_of_sides=10,radius=5).add_to(marker_cluster)

heatdata = full[["y", "x", "bike_num"]].values.tolist()
HeatMap(heatdata).add_to(schools_map)
schools_map.save('schools_map.html')  # 保存到本地
webbrowser.open('schools_map.html')  # 在浏览器中打开
