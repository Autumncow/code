#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# author : zlq16
# date   : 2020/4/16
from utility import EPSFloat, Zero


class Location:
    __slots__ = ["_x", "_y"]

    def __init__(self, x: EPSFloat, y: EPSFloat):
        self._x: EPSFloat = x
        self._y: EPSFloat = y

    @property
    def x(self) -> EPSFloat:
        return self._x

    @property
    def y(self) -> EPSFloat:
        return self._y

    def __repr__(self):
        return "({0},{1})".format(self._x, self._y)

    def __bool__(self):
        return self.x != Zero and self.y != Zero

    def __add__(self, other):
        if isinstance(other, tuple) or isinstance(other, list):
            if len(other) != 2:
                raise Exception("list 和 tuple的长度必须是2")
            return Location(self.x + other[0], self.y + other[1])
        elif isinstance(other, Location):
            return Location(self.x + other.x, self.y + other.y)
        else:
            raise Exception("不可以处理tuple, list, Location以外的类型")

    def __sub__(self, other):
        if isinstance(other, tuple) or isinstance(other, list):
            if len(other) != 2:
                raise Exception("list 和 tuple的长度必须是2")
            return Location(self.x - other[0], self.y - other[1])
        elif isinstance(other, Location):
            return Location(self.x - other.x, self.y - other.y)
        else:
            raise Exception("不可以处理tuple, list, Location以外的类型")

    def __radd__(self, other):
        if isinstance(other, tuple) or isinstance(other, list):
            if len(other) != 2:
                raise Exception("list 和 tuple的长度必须是2")
            return Location(self.x + other[0], self.y + other[1])
        elif isinstance(other, Location):
            return Location(self.x + other.x, self.y + other.y)
        else:
            raise Exception("不可以处理tuple, list, Location以外的类型")

    def __rsub__(self, other):
        if isinstance(other, tuple) or isinstance(other, list):
            if len(other) != 2:
                raise Exception("list 和 tuple的长度必须是2")
            return Location(other[0] - self.x, other[1] - self.y)
        elif isinstance(other, Location):
            return Location(other.x - self.x, other.y - self.y)
        else:
            raise Exception("不可以处理tuple, list, Location以外的类型")


NoneLocation = Location(Zero, Zero)

if __name__ == '__main__':
    print(Location(EPSFloat(3), Zero))
    if NoneLocation:
        print("dsada")
    else:
        print("success")

    print([1.7, 2] - Location(EPSFloat(3), Zero))
